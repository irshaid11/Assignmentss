def reverse_word(word):
	return word[::-1]


def capitalize_word(word):
	return word.capitalize()