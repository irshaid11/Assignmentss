def get_average(lst):
	summ = 0
	for el in lst:
		summ += el
	return summ / len(lst)